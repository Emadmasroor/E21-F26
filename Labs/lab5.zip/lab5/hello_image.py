import numpy as np
from PIL import Image

def main():

    img_w = 128
    img_h = 96

    px_scl = 1.0 / (0.5 * img_h)

    image_data = np.zeros((img_h, img_w, 3), dtype=np.uint8)
    
    for row in range(img_h):

        y = (row - 0.5*img_h + 0.5) * px_scl

        for col in range(img_w):

            x = (col - 0.5*img_w + 0.5) * px_scl

            v = np.array([np.cos(2*x), np.sin(2*y), np.cos(2*(x+y))])
            v = 0.5 * v + 0.5
            v = (v * 255).astype(np.uint8)

            image_data[row, col] = v
            
    image = Image.fromarray(image_data, mode='RGB')

    image.save('test.png')

    print('wrote test.png')

######################################################################

main()
