from datetime import datetime
import numpy as np
import numpy.polynomial.polynomial as nppoly
from PIL import Image
import sys

# let's define some constants to use in our program

IMAGE_WIDTH_HEIGHT = (128, 96)

CAMERA_POS = [0, -3, 3]
CAMERA_TGT = [0, 0, 0]
CAMERA_UP = [0, 1, 0]

LIGHT_DIR = [-1, 1, 2]

CAMERA_F = 0.6

SPHERE_RAD = 2.0

TORUS_R1 = 0.6
TORUS_R2 = 1.4

MARCH_TOL = 1e-3
MARCH_MAX_ITER = 100
MARCH_MAX_DIST = 10.0

DK_TOL = 1e-9
IM_TOL = 1e-9

######################################################################

def vec3(x, y, z):
    '''Construct a length-3 array from 3 scalars.'''
    return np.array([x,y,z], dtype=float)

def length(v):
    '''Thin wrapper on numpy's norm function.'''
    return np.linalg.norm(v)

def normalize(v):
    '''Return the vector v, scaled to a unit vector.'''
    return v / length(v)

def vec2color(v):
    '''Convert a 3D vector to an RGB color.'''
    return (np.clip(v, 0.0, 1.0)*255).astype(np.uint8)

######################################################################

def guess_roots(coeffs):
    '''Given polynomial coefficients in increasing order of exponent, come
    up with some guesses for polynomial roots.
    '''

    # a degree n polynomial has n + 1 coefficients and n roots
    ncoeff = len(coeffs)
    nroots = ncoeff - 1

    cmax = np.max(np.abs(coeffs))
    cmin = np.maximum(cmax * 0.1, np.min(np.abs(coeffs)))

    mags = np.linspace(cmin, cmax, nroots)
    theta = 2*np.pi / nroots

    roots = np.empty(nroots, dtype=np.complex128)

    for i in range(nroots):
        c = np.cos(theta*i)
        s = np.sin(theta*i)
        roots[i] = (c + 1j*s)*mags[i]

    return roots

######################################################################

def smallest_positive_real_root(coeffs, dk_tol, im_tol):
    '''Given polynomial coefficients in increasing order of exponent,
    return the smallest real (or nearly real) root which is greater
    than zero, or return None if there is no such root.
    '''

    roots = durand_kerner(coeffs, dk_tol)

    best_root = None

    for root in roots:
        re, im = np.real(root), np.imag(root)
        if np.abs(im) < im_tol*np.abs(re) and re > 0:
            if best_root is None:
                best_root = re
            else:
                best_root = np.minimum(best_root, re)

    return best_root

######################################################################

def test_roots():

    '''Test the durand_kerner() function. This will raise an
    AssertionError if rootfinding does not work.'''
    
    #coeffs = np.array([1.0, -3.0, 3.0, 5.0])
    coeffs = np.array([5.0, 3.0, -3.0, 1.0])
    
    roots_np = np.sort( nppoly.polyroots(coeffs) )
    
    roots_dk = np.sort( durand_kerner(coeffs, DK_TOL) )

    delta = roots_np - roots_dk

    relerr = np.abs(delta) / np.abs(roots_np)

    print('np roots:', roots_np)
    print('dk roots:', roots_dk)
    print('relerr:', relerr)

    if np.max(relerr) < DK_TOL:
        print('rootfinding test passed!')
    else:
        print('rootfinding test FAILED!')

    print
        
    assert np.max(relerr) < 10.0 * DK_TOL

######################################################################

def sphere_coeffs(ro, rd):

    '''Returns the coefficients a, b, c of the quadratic polynomial
    resulting from intersecting a ray with origin ro and direction 
    rd with a sphere at the origin with radius SPHERE_RAD.'''


    a = np.dot(rd, rd)
    b = 2*np.dot(ro, rd)
    c = np.dot(ro, ro) - SPHERE_RAD**2

    coeffs = np.array([c, b, a])

    return coeffs

def sphere_normal(pos):
    '''Returns the surface normal vector to a sphere centered
    at the origin, sampled at the given input position.'''
    return normalize(pos)

def sphere_distance(pos):
    '''Return the signed distance from the point at position pos to the
    sphere centered at the origin with radius rad. The returned
    distance will be positive is pos is outside the sphere, negative
    if pos is inside, or zero if pos is on the boundary.'''
    return length(pos) - SPHERE_RAD

def torus_coeffs(ro, rd):

    '''Returns the coefficients of the quartic polynomial
    resulting from intersecting a ray with origin ro and direction 
    rd with a torus at the origin with minor and major radii 
    of TORUS_R1 and TORUS_R2, respectively.'''

    r1_sqr = TORUS_R1**2
    r2_sqr = TORUS_R2**2

    alpha = np.dot(rd,rd)
    beta = 2*np.dot(ro,rd)
    gamma = np.dot(ro, ro) - r1_sqr - r2_sqr

    pz = ro[2]
    dz = rd[2]

    coeffs = np.array([
        gamma**2 + 4*r2_sqr*(pz*pz - r1_sqr),
        2*beta*gamma + 8*r2_sqr*pz*dz,
        beta**2 + 2*alpha*gamma + 4*r2_sqr*dz*dz,
        2*alpha*beta,
        alpha**2,
    ])

    return coeffs

def torus_normal(pos):
    '''Returns the surface normal vector to a torus centered
    at the origin with radii specified by constants above, 
    sampled at the given input position.'''

    x, y, z = pos

    l = np.sqrt(x**2 + y**2)

    rdiff = l - TORUS_R2

    return normalize(vec3(x*rdiff/l, y*rdiff/l, z))



######################################################################

def durand_kerner(coeffs, tol):
    '''Given polynomial coefficients in increasing order of exponent,
    return a list of all (possibly complex) roots of the
    polynomial.'''

    # TODO: replace nppoly.polyroots(coeffs) with your implementation of the
    # Durand-Kerner method. You should stop iterating when the
    # approximate relative error for all root estimates is less than
    # the provided tolerance.
    #
    # You will likely want to start by calling guess_roots(coeffs).

    return nppoly.polyroots(coeffs)

def torus_distance(pos):

    '''This should be your implementation of the torus distance
    function. Currently it is broken (returns distance to pill-shaped
    object instead).''' 

    r1 = TORUS_R1
    r2 = TORUS_R2

    # TODO: fixme - torus, not pill!
    pc = vec3(np.clip(pos[0], -r2, r2), 0, 0)
    return length(pos-pc) - r1

######################################################################

def render_scene(shape, method, 
                 coeffs_or_dist_func, 
                 normal_func, 
                 base_color):

    '''Renders the scene with a sphere or torus primitive,
    using either raytracing or raymarching. 

    Some math/code inside this function is outside the scope of the
    E19 class, but feel free to ask in the alternate week meeting
    or during office hours if you want to learn more about it.'''

    img_w, img_h = IMAGE_WIDTH_HEIGHT

    pos = vec3(*CAMERA_POS)
    tgt = vec3(*CAMERA_TGT)
    up = vec3(*CAMERA_UP)

    l = normalize(vec3(*LIGHT_DIR))

    view_z = normalize(tgt - pos)
    view_x = normalize(np.cross(view_z, up))
    view_y = normalize(np.cross(view_x, view_z))

    R = np.array([view_x, view_y, view_z]).transpose()

    ro = pos

    image_data = np.zeros((img_h, img_w, 3), dtype=np.uint8)

    px_scl = 1.0 / (0.5 * img_h)

    start_time = datetime.now()

    for row in range(img_h):

        print(f'  {shape} {method} row {row+1}/{img_h}\r', end='')

        y = -(row - 0.5*img_h + 0.5) * px_scl

        for col in range(img_w):

            x = (col - 0.5*img_w + 0.5) * px_scl

            rd = normalize(vec3(x*CAMERA_F, y*CAMERA_F, 1))
            rd = np.dot(R, rd)

            hit_pos = None
            hit_normal = None

            if method == 'trace':
                
                coeffs = coeffs_or_dist_func(ro, rd)

                t = smallest_positive_real_root(coeffs, DK_TOL, IM_TOL)

                if t is not None:

                    hit_pos = ro + rd * t

                    hit_normal = normal_func(hit_pos)
                
            elif method == 'march':

                t = MARCH_TOL
                hit = False

                for i in range(MARCH_MAX_ITER):
                    pos = ro + t * rd
                    d = coeffs_or_dist_func(pos)
                    if np.abs(d) < MARCH_TOL:
                        hit_pos = pos
                        hit_normal = vec3(0, 0, 0)
                        h = 1e-4
                        for i in range(3):
                            delta = vec3(0, 0, 0)
                            delta[i] = h
                            d1 = coeffs_or_dist_func(pos + delta)
                            d0 = coeffs_or_dist_func(pos - delta)
                            hit_normal[i] = (d1 - d0) / (2.0*h)
                        hit_normal = normalize(hit_normal)
                        break

                    t += d
                    if t >= MARCH_MAX_DIST:
                        break


            else:

                raise RuntimeError('invalid method')

            if hit_pos is not None:

                # shade the image
                NdotL = np.maximum(np.dot(hit_normal, l), 0.0)

                ka = 0.2
                kd = 0.8

                H = normalize(l - rd)
                NdotH = np.maximum(np.dot(hit_normal, H), 0.0)

                diffamb = (ka + kd*NdotL) * base_color

                spec = vec3(1,1,1) * np.power(NdotH, 120.0)

                image_data[row, col] = vec2color(diffamb + spec)

    elapsed = (datetime.now() - start_time).total_seconds()

    image = Image.fromarray(image_data, mode='RGB')

    filename = shape + '_' + method + '.png'

    image.save(filename)

    print('  rendered', filename, 'in', elapsed, 'seconds')
    
######################################################################

def main():
    
    test_roots()

    cases = [
        ('sphere', 'trace', sphere_coeffs, sphere_normal, vec3(1, 0.5, 0)),
        ('sphere', 'march', sphere_distance, None, vec3(0.5, 1, 0)),
        ('torus', 'trace', torus_coeffs, torus_normal, vec3(0, 0.5, 1)),
        ('torus', 'march', torus_distance, None, vec3(0.5, 0, 1))
    ]

    print('rendering images...\n')

    for shape, method, cdfunc, nfunc, color in cases:
        render_scene(shape, method, cdfunc, nfunc, color)

######################################################################

if __name__ == '__main__':
    main()
